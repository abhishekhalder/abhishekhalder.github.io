close all; clear; clc;

set(groot,'defaultAxesTickLabelInterpreter','latex');  
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

%% parameters
N = 4; % number of vehicles

h = 0.01; % sampling time

T = 200; % final time

d = 245; % desired separation distance in ft.

%% system and cost matrices
A = eye(N); B = h*eye(N); 

C = toeplitz([-1 1 zeros(1,N-2)]); C = triu(C(1:N-1,:));

M = eye(N-1); Q = M; R = eye(N);


%% Backward matrix-vector recursion
% initialize
P = cell(length(T),1); v = cell(length(T),1);
K = cell(length(T),1); Kv = cell(length(T),1);
u_feedforward = cell(length(T),1);
% terminal conditions
P{T} = C' * M * C; v{T} = C' * M * d * ones(N-1,1);

for k = T-1:-1:1
    % Riccati update
    P{k} = (C' * Q * C) + A' * (inv(eye(N) + P{k+1}*B*(inv(R))*B')) * P{k+1} * A;
    % vector update
    v{k} = (C' * Q * d * ones(N-1,1)) + A' * (inv(eye(N) + P{k+1}*B*(inv(R))*B')) * v{k+1};
    % feedforward control
    Kv{k} = (inv(R + B' * P{k+1} * B)) * B';    
    u_feedforward{k} = Kv{k} * v{k+1};   
    % feedback gain
    K{k} =  Kv{k} * P{k+1} * A;    
end

%% simulate output tracking performance
% initialize states, controls and outputs
x = zeros(N,T); x(:,1) = [0; 250; 480; 780];
u = zeros(N,T);
y = zeros(N-1,T);
% forward propagate the state vector
for k=1:T-1
    % optimal control
     u(:,k) = -K{k} * x(:,k) + u_feedforward{k}; 
     % optimal state recursion
     x(:,k+1) = A * x(:,k) + B * u(:,k);
end
% output vector
for k=1:T
    y(:,k) = C * x(:,k);
end
% plot stuff
figure(1) % output trajectories
for i=1:N-1
    plot(1:T, y(i,:), '-o')
    hold on
end
plot(0:T, d*ones(size(0:T)), '-k', 'LineWidth', 2)
xlabel('$k$ [s]','FontSize',35); 
ylabel('Inter-vehicle separation [ft.]','FontSize',35);
set(gca,'FontSize',30)
legend('$x_{2}-x_{1}$', '$x_{3}-x_{2}$','$x_{4}-x_{3}$','$d$','FontSize',24,'Location','best','Interpreter','latex')

figure(2) % control trajectories
for i=1:N
    plot(1:T, u(i,:), '-o')
    hold on
end
xlabel('$k$ [s]','FontSize',35); 
ylabel('Deviation from speed limit [ft/s]','FontSize',35);
set(gca,'FontSize',30)
legend('$u_{1}-v$', '$u_{2}-v$','$u_{3}-v$','$u_{4}-v$','FontSize',24,'Location','best','Interpreter','latex')